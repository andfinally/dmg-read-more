=== DMG Read More ===
Contributors:      Andfinally
Tags:              block
Tested up to:      6.7
Stable tag:        0.1.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Adds Gutenberg block allowing authors to search for a published post and add a link to it in the post content.

== Description ==

This plugin adds a Gutenberg block that allows authors to search for a published post in the post edit sidebar. On selecting a post from the results, the block places a link to the selected post in the post content.

The plugin also adds a WP-CLI command `wp dmg-read-more search` which searches published posts for instances of the block.

== Installation ==

1. Install the plugin through the WordPress plugins screen using the `dmg-read-more.zip` installation file.
1. Activate the plugin through the 'Plugins' screen in WordPress.

== Changelog ==

= 1.0.0 =
* Release
